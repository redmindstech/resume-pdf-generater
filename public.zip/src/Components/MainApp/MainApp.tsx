import React from "react";
import "./MainApp.scss";

function MainApp() {
    return (
        <main>
            <div className="pfd-preview">
                <div className="pfd-preview-container">

                </div>
            </div>
        </main>
    );
}

export default MainApp;
