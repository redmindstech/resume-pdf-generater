export interface ProfilePdfProp {
    profile: boolean;
}
export interface EducationPdfProp {
    education: boolean;
}
export interface SkillsPdfProp {
    skills: boolean;
}
export interface WorkPdfProp {
    work: boolean;
}
export interface ProjectsPdfProp {
    projects: boolean;
}
export interface AwardsPdfProp {
    awards: boolean;
}