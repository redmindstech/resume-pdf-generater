import { FormResumePdf } from "../";

function NavigationApp() {
	return (
		<nav>
			<FormResumePdf />
		</nav>
	);
}

export default NavigationApp;
