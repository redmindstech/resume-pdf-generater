import React from "react";
// import "./HeaderApp.scss";
import { ButtonForm } from "../";

function FooterApp() {
    return (
        <footer>
            <ButtonForm title="Get PDF"/>
        </footer>
    );
}

export default FooterApp;
